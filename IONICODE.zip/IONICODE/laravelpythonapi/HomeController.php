<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Quotation;
use App\Questionnaire;
use App\User;
use Session;
use Hash;
use Illuminate\Support\Facades\Auth;
use Redirect;
use Carbon\Carbon;
use Twilio\Rest\Client;
use PHPExcel; 
use PHPExcel_IOFactory;
class HomeController extends Controller
{
    




    /**
     * Create a new controller instance.
     *
     * @return void
     */
  

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
        
 






    public function index()
    {
		echo"joy";
		
       //return view('home');
    }
    

    public function helloworld()
    {


        echo"helloworld";
    }
    
    
public function hello($name)
{


echo "hello".$name;


}


    public function add($a,$b)

    {

echo $a+$b;

    }

    public function dateexample()
    {




$date = '25-05-2010';
echo date('Y-m-d', strtotime($date));//convert to y-m-d format

echo"<br>";
$date2 = date("y-m-d", strtotime('now'));//todays date

echo $date2;


echo"<br>";



$now = strtotime("2023-12-20"); // or your date as well
$your_date = strtotime("2023-12-31");


$datediff =  $your_date-$now;

echo round($datediff/(60 * 60 * 24));



echo"<br>";



date_default_timezone_set('Asia/Kolkata');
echo  date('Y-m-d H:i:s', strtotime("today"));
echo  date('Y-m-d H:i:s', strtotime("+2 hours"));
echo date('Y-m-d H:i:s', strtotime("-2 hours"));
echo date('Y-m-d H:i:s', strtotime("next Monday"));





    }




public  function loop()
{

$max=3;
for ($i = 0; $i < $max; $i++)
{


echo $i;


}



$arr = array(1, 2, 3, 4);

echo"<br>";



foreach ($arr as $key => $value) {
    // $arr[3] will be updated with each value from $arr...
    echo "{$value} ";



}


$a=10;
$b=5;
if ($a > $b):
    echo $a." is greater than ".$b;
elseif ($a == $b): // Note the combination of the words.
    echo $a." equals ".$b;
else:
    echo $a." is neither greater than or equal to ".$b;
endif;

echo"<br>";









}


public function  arrayexample()
{


$fruits = [
            'apple' => 0.99,
            'banana' => 0.49,
            'orange' => 0.79,
            'grape' => 1.29,
        ];


print_r($fruits);




foreach ($fruits as $key => $value) {
    // $arr[3] will be updated with each value from $arr...
  echo"<br>";

    echo "{$value} ";

}




}






    
    
}