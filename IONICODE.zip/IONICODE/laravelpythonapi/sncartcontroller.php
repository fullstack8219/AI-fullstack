<?php
   
namespace App\Http\Controllers\API\API;
   
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\User;
//use Session;
use Illuminate\Support\Facades\Session;
use Hash;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Pagination\Paginator;
class sncartcontroller extends Controller
{
	



public function helloworld()
{


echo "helloworld";

}


public function add($a,$b)
{


echo $a+$b;

}



public function getproducts1()
{
	
	header ("Access-Control-Allow-Origin: *");
    header ("Access-Control-Expose-Headers: Content-Length, X-JSON");
    header ("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    header ("Access-Control-Allow-Headers: *");
	header('Content-type: Application/json');
	$user=User::all();
	$products=DB::table('products1')->get();
	$result = $this->paginate($products);
    return response()->json(['success' => $result], 200);




}
	
	
	
public function paginate($items, $perPage = 1001, $page = null, $options = [])
    {	
         $page = $page ?: (\Illuminate\Pagination\Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof \Illuminate\Support\Collection ? $items : \Illuminate\Support\Collection::make($items);
        return new \Illuminate\Pagination\LengthAwarePaginator(array_values($items->forPage($page, $perPage)->toArray()), $items->count(), $perPage, $page, $options);
    }	

	
	
	
public function getlogincheck()
{


	
	echo"joy";
			echo"<br>";

		
		if(Auth::attempt(['email' =>'vsanth1@gmail.com', 'password' =>'vson12345'])){ 

            echo'User logpin successfully';
									echo"<br>";

	                       $user = Auth::user(); 

	   print_r($user->email);

	$success['id']=$user->id;
						echo"<br>";

		$success['name']=$user->name;
						echo"<br>";

				$success['email']= $user->email;
			
session()->put('name',$user->email);	
			session(['vname' => 'data']);
			session()->save();
        } 
        else{ 
            echo'rong';
        } 
		
print_r(session()->get('name'));	
	
}
	
	
	
	
    public function login1($a,$b)
{

   header ("Access-Control-Allow-Origin: *");
    header ("Access-Control-Expose-Headers: Content-Length, X-JSON");
    header ("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    header ("Access-Control-Allow-Headers: *");
		
		
		
		//header('Content-type: Application/json');
   
	//	echo $a;
	//echo $b;
   
 $credentials = [
        'email' => $a,//'vsanth@gmail.com', 
      'password' =>$b//'vson12345'
    ];

    if( auth()->attempt($credentials) ){ 
     
//echo"joy1";

      return response()->json([$a,$b], 200);


    } else { 


      return response()->json(['wrong'], 200);


   } 



  }

public function user_detail() 
  { 
	
	header ("Access-Control-Allow-Origin: *");
    header ("Access-Control-Expose-Headers: Content-Length, X-JSON");
    header ("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    header ("Access-Control-Allow-Headers: *");
		
		
		
		header('Content-type: Application/json');
	
	


		
		return response()->json(['success' => Auth::user()->email], 200); 
	



  } 

  
    public function sessioneg1()
    {
       
		
print_r(session()->get('name'));	
	
		
    }
	
	


	
	
	

}
	
