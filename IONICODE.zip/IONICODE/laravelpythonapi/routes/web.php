

<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//Route::get('/', 'User\UserProductController@v');


Route::get('/home', 'HomeController@index')->name('home');
Route::get('/helloworld', 'HomeController@helloworld')->name('helloworld');
Route::get('/add/{a}/{b}', 'HomeController@add')->name('add');
Route::get('/hello/{name}', 'HomeController@hello')->name('hello');
Route::get('/dateexample/', 'HomeController@dateexample')->name('dateexample');
Route::get('/loop', 'HomeController@loop')->name('loop');
Route::get('/arrayexample', 'HomeController@arrayexample')->name('arrayexample');

Route::post('/login1', 'Auth\LoginController@login1');


Auth::routes();




Route::get('/body',function(){
    return view('admin.index');
})->name('master.home');

Route::group(["name" => "admin", "prefix" => "master", "namespace" => "Admin"], function(){

    Route::resource('category','CategoryController');
    Route::resource('product','ProductController');

});



Route::fallback(function(){
    return view('404page');
});
