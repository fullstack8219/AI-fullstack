<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});





Route::group(array('namespace' => 'Api'

), function () {

	
	Route::get('helloworld','API\sncartcontroller@helloworld');
			Route::get('add/{a}/{b}','API\sncartcontroller@add');

Route::get('hello','API\RegisterController@hello');
	Route::get('getpageproduct','API\sncartcontroller@getproducts1');
		Route::get('user_detail','API\sncartcontroller@user_detail');


	Route::get('getlogincheck','API\sncartcontroller@getlogincheck');

	
	Route::get('sessioneg1','API\RegisterController@sessioneg1');
Route::get('login1/{email}/{pwd}', 'API\sncartcontroller@login1');
	
	





});


