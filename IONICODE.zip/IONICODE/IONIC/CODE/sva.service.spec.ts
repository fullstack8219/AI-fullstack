import { TestBed } from '@angular/core/testing';

import { SvaService } from './sva.service';

describe('SvaService', () => {
  let service: SvaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SvaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
