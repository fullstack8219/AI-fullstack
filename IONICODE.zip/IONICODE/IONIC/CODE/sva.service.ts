import { Injectable } from '@angular/core';
import { BehaviorSubject } from "rxjs";
import { HttpClient } from "@angular/common/http";
import {HttpErrorResponse} from "@angular/common/http";
import { Observable, of } from 'rxjs';
import { Subject } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class SvaService {






//https://fakestoreapi.com/products

constructor(private httpClient: HttpClient) { 



}

  public cartItemList : any =[]
  orderdetails:any[] = [];
  productdetails:any[] = [];


  public productList = new BehaviorSubject<any>([]);
  public search = new BehaviorSubject<string>("");
      orderdetailsSubject = new Subject();
  productdetailsSubject = new Subject();


  getProducts() {
    return this.productList.asObservable();
  }

  setProduct(product : any) {
    this.cartItemList.push(...product);
    


    this.productList.next(product);
  }

  addtoCart(product : any) {

let foundMovie = false;

for (let i = 0; i < this.cartItemList.length; i++) {
      if (product.id === this.cartItemList[i].id) {
      this.cartItemList[i].Qty++;
        foundMovie = true;

     }
   }

    if (!foundMovie) {
      this.cartItemList.push(product);
    }



   // this.cartItemList.push(product);
    this.productList.next(this.cartItemList);
    this.getTotalPrice();
    console.log(this.cartItemList)
  }

  getTotalPrice() : number {
    let grandTotal = 0;
    this.cartItemList.map((a:any) => {
      grandTotal += (a.Qty * a.Price);
    })

    return grandTotal;
  }

  removeCartItem(product: any) {

    this.cartItemList.map( (a:any, index:any) => {
      if(product.id === a.id){
        this.cartItemList.splice(index,1);
      }
    })

    this.productList.next(this.cartItemList);
  }

  removeAllCart() {
    this.cartItemList = []
    this.productList.next(this.cartItemList);
  }



 orderdetail(order:any) {
    this.orderdetails =[];




    this.orderdetails.push(order);
    

    this.orderdetailsSubject.next(this.orderdetails);
  //  alert(this.orderdetailsSubject.getValue());


  }




  getAllorderdetails(){
    return this.orderdetails;
  }



  getAllProductdetails(){
    return this.productdetails;
  }





 addproductdetails(product:any) {

    this.productdetails =[];




    this.productdetails.push(product);
    

    this.productdetailsSubject.next(this.productdetails);


  }



  

}
