import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable,Subject,of} from 'rxjs';
import { SvaService } from '../sva.service';
import { HttpClient } from '@angular/common/http';
import {HttpErrorResponse} from "@angular/common/http";
import { Router } from '@angular/router';
import { ApicallService } from '../apicall.service';






@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
})
export class CartPage implements OnInit {



  catalog: any;


  cartitems: any = [];
total:Number;


deviceArray1: any[] = [];

deviceArray2: any[] = [];
  public products : any = [];


  public grandTotal !: number;

public myDate:any;
public myDatee:any;

public date:any;

timeEntered1 = new Date();
    currentSelection = '50';
hideMe:any;

eventSource = [];
//date:any;

  constructor(private router: Router,private http:HttpClient,private apicall:ApicallService,public sva:SvaService) {



     this.date=new Date().toISOString();
  


this.apicall.getlablogincheck('vsanth1@gmail.com','vson12345').subscribe((data: any) => {

      this.deviceArray2 = JSON.parse(JSON.stringify(data));


    });

  }


  calendar = {
    mode: "month",
   step:30 ,
    currentDate: new Date(new Date().getFullYear(), new Date().getMonth()+1, 1),
     dateFormatter: {
            formatMonthViewDay: function(date:Date) {
                return date.getDate().toString();
            },
            formatMonthViewDayHeader: function(date:Date) {
                return 'MonMH';
            },
            formatMonthViewTitle: function(date:Date) {
                return 'testMT';
            },
            formatWeekViewDayHeader: function(date:Date) {
                return 'MonWH';
            },
            formatWeekViewTitle: function(date:Date) {
                return 'testWT';
            },
            formatWeekViewHourColumn: function(date:Date) {
                return 'testWH';
            },
            formatDayViewHourColumn: function(date:Date) {
                return 'testDH';
            },
            formatDayViewTitle: function(date:Date) {
                return 'testDT';
            }
        }
  };

  selectedDate = new Date(new Date().getFullYear(), new Date().getMonth()+1, 1);





  addNewEvent() {
    const start = this.selectedDate;
    const end = this.selectedDate;
    end.setMinutes(end.getMinutes() + 60);

    // event object created to include semi-random title
    const event = {
      title: "Event #" + start.getMinutes(),
      startTime: start,
      endTime: end,
      allDay: false,
    };

  }

  onViewTitleChanged(title:any) {
    alert('ok'+title);
  }

  onEventSelected(event:any) {
   alert(
      "Event selected:" +
        event.startTime +
        "-" +
        event.endTime +
        "," +
        event.title
    );
  }

  onTimeSelected(ev:any) {
    console.log(
      "Selected time: " +
        ev.selectedTime +
        ", hasEvents: " +
        (ev.events !== undefined && ev.events.length !== 0) +
        ", disabled: " +
        ev.disabled
    );
    this.selectedDate = ev.selectedTime;
  }

  onCurrentDateChanged(event: Date) {
    this.date= event;
  }

  onRangeChanged(ev:any) {
    alert(
      "range changed: startTime: " + ev.startTime + ", endTime: " + ev.endTime
    );
  }
  ngOnInit() {


this.sva.getProducts().subscribe(
      (res) => {
        this.products = res;
        this.grandTotal = this.sva.getTotalPrice();
      },
      (message: HttpErrorResponse) => {
        alert(message);
      }
    );

  }

}
