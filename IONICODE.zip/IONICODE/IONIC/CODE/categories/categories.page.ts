import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApicallService } from '../apicall.service';
import { MenuController } from '@ionic/angular';;


@Component({
  selector: 'app-categories',
  templateUrl: './categories.page.html',
  styleUrls: ['./categories.page.scss'],
})
export class CategoriesPage implements OnInit {
  


  public sliderOptions = {
    initialSlide: 1,
    pagination: {
      el: ".swiper-pagination",
      type: "bullets",
      clickable: true
    }
  };



  // set app banner slides
  slideOpts = {
    initialSlide: 0,
    speed: 400,
    loop: true,
    autoplay: {
      delay: 4000,
      disableOnInteraction: false,
    }
  };



  visiable = false;//for which home it display
  // For products
  public products: any = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
  public featured: any = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
type:any;

deviceArray1: any[] = [];
deviceArray2: any[] = [];
   itemsToDisplay =[];
item:any;
data:any;

 slice: number = 5;
   usersList:any[]=[];


  constructor(private apicall:ApicallService,private http: HttpClient,public menuCtrl: MenuController) {

   }

  ngOnInit() {




 this.apicall.getlabproducts().subscribe(data => {

        this.deviceArray1 = JSON.parse(JSON.stringify(data.success));





 this.apicall.getlabcategories().subscribe(data => {

        this.deviceArray2 = JSON.parse(JSON.stringify(data.success));

    });




    });




  }



 openMenu() {
   this.menuCtrl.open();
 }

 closeMenu() {
   this.menuCtrl.close();
 }

 toggleMenu() {
   this.menuCtrl.toggle();
 }






}
