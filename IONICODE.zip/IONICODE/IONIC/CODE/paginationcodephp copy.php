<?php
   
namespace App\Http\Controllers\API\API;
   
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\User;
//use Session;
use Illuminate\Support\Facades\Session;
use Hash;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Pagination\Paginator;
class sncartcontroller extends Controller
{
	

public function getproducts1()
{
	
	header ("Access-Control-Allow-Origin: *");
    header ("Access-Control-Expose-Headers: Content-Length, X-JSON");
    header ("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    header ("Access-Control-Allow-Headers: *");
	header('Content-type: Application/json');
	$user=User::all();
	$products=DB::table('products1')->get();
	$result = $this->paginate($products);
    return response()->json(['success' => $result], 200);




}
	
	
	
public function paginate($items, $perPage = 1001, $page = null, $options = [])
    {	
         $page = $page ?: (\Illuminate\Pagination\Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof \Illuminate\Support\Collection ? $items : \Illuminate\Support\Collection::make($items);
        return new \Illuminate\Pagination\LengthAwarePaginator(array_values($items->forPage($page, $perPage)->toArray()), $items->count(), $perPage, $page, $options);
    }	

}
	
