import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable,Subject,of} from 'rxjs';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';

import {HttpErrorResponse} from "@angular/common/http";

import { SvaService } from '../sva.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.page.html',
  styleUrls: ['./productdetails.page.scss'],
})
export class ProductdetailsPage implements OnInit {




  public sliderOptions = {
    initialSlide: 1,
    pagination: {
      el: ".swiper-pagination",
      type: "bullets",
      clickable: true
    }
  };



  // set app banner slides
  slideOpts = {
    initialSlide: 0,
    speed: 400,
    loop: true,
    autoplay: {
      delay: 4000,
      disableOnInteraction: false,
    }
  };



bikesInCart = [];
//public deviceArray1: [];

deviceArray1: any[] = [];
deviceArray2: any[] = [];


  allProducts: any = [];

  isProductInCart=false;

  public products : any = [];


  public grandTotal !: number;



  constructor(private router: Router,private http: HttpClient,public sva:SvaService) {

       this.deviceArray2=JSON.parse(JSON.stringify(this.sva.getAllProductdetails()));



   }










  addToCart(item:any){    
    //    this.sva.addproductdetails(product);

    this.sva.addtoCart(item);

    //this.CartService.addProductToCart(product);
   // this.isProductInCart = true;
                this.router.navigate(['/cart']);
//

  }






  ngOnInit() {




this.getlab1().subscribe((data: any) => {

      this.deviceArray1 = JSON.parse(JSON.stringify(data.success));



    });


this.sva.getProducts().subscribe(
      (res) => {
        this.products = res;
        this.grandTotal = this.sva.getTotalPrice();
      },
      (message: HttpErrorResponse) => {
        alert(message);
      }
    );


  }




getlab1(): Observable<any> {
    return this.http.get('https://fullstackdeveloperfreelancer.com/sessioncart/api/getproducts_details/7');
  }



}
