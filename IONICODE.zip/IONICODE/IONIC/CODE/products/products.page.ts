import { Component,OnInit,ViewChild,inject} from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable,Subject,of} from 'rxjs';
import { IonInfiniteScroll } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

import { ApicallService } from '../apicall.service';
import { SvaService } from '../sva.service';



@Component({
  selector: 'app-products',
  templateUrl: './products.page.html',
  styleUrls: ['./products.page.scss'],
})
export class ProductsPage implements OnInit {

  public products!: string;



  private activatedRoute = inject(ActivatedRoute);


slice: number = 5;

  


deviceArray1: any[] = [];
deviceArray2: any[] = [];
perpage: any[] = [];
currentpage: any[] = [];
nextpageurl: any[] = [];
lastpageurl: any[] = [];
to : any[] = [];
  pageno:any;

page=1;
data:any;
users:any;
perPage=0;
totalData=0;
totalPage=0;
isProductInCart=false;


  constructor(private http: HttpClient,private router:Router,public sva:SvaService)

{
this.pageno=1;
    //console.log(this.usersList);
 



 this.getlabproducts().subscribe(data => {


      this.deviceArray2 = JSON.parse(JSON.stringify(data.success.data));
    
this.perpage= JSON.parse(JSON.stringify(data.success.per_page));
//this.currentpage= JSON.parse(JSON.stringify(data.success.current_page));
this.nextpageurl= JSON.parse(JSON.stringify(data.success.next_page_url));
this.lastpageurl= JSON.parse(JSON.stringify(data.success.last_page_url));
this.to= JSON.parse(JSON.stringify(data.success.to));


  






    });











  }






  loadData(event:any) {
    console.log("load data called");
   
  //let nextPageUrl = this.pageno++;
    //console.log("next page:"+nextPageUrl);
    


  // for (let i = 0; i < 20; i++) {









//}
    
  

   // for (let i = 0; i < 20; i++) {
     // this.usersList.push(newData);
    //}


    setTimeout(() => {
      console.log('Done');

      this.deviceArray2=[];
              this.pageno++;


 this.getlabsingleproducts().subscribe(data => {


 


      this.deviceArray2 = JSON.parse(JSON.stringify(data.success.data));


this.perpage= JSON.parse(JSON.stringify(data.success.per_page));
this.currentpage= JSON.parse(JSON.stringify(data.success.current_page));
this.nextpageurl= JSON.parse(JSON.stringify(data.success.next_page_url));
this.lastpageurl= JSON.parse(JSON.stringify(data.success.last_page_url));
this.to= JSON.parse(JSON.stringify(data.success.to));


    });


      event.target.complete();











    }, 500);
  
}

  ngOnInit() {











}










getlabproducts(): Observable<any> {
    return this.http.get('web link xxx');
  }



getlabsingleproducts(): Observable<any> {
    return this.http.get('web link/api/getpageproduct?page='+this.pageno);




  }






  addToCart(product:any){    
        this.sva.addproductdetails(product);


    //this.CartService.addProductToCart(product);
    this.isProductInCart = true;
                this.router.navigate(['/productdetails']);


  }





}

